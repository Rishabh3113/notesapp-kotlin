package com.example.notify

class data(val email: String,
           val name: String,
           val mobile: String) {

}