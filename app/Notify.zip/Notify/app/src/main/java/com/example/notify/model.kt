package com.example.notify

 data class model(val title: String, val body: String,){
           constructor() : this("", "")
 }
//data class in kotlin is like this





